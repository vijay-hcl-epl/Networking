# push branch
```
	git push origin origin/linux-3.18.y:origin/linux-3.18.y
```

# push tags
```
	git push origin v3.18
```

